const config = {
  apiUrl: 'http://localhost:12455'
  // apiUrl: 'http://localhost:3000'

};

export default config;